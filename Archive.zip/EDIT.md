# EDIT HTML
1.  from line 97 to 149 is navigation part

    ![idea_08](./img/2.png)

2.  from line 157 to 220 is the slides part

    ![idea_01](./img/1.png)

3.  from line 227 to 286 is the about part

    ![idea_02](./img/3.png)

4.  from line 289 to 430 is the product part, the image is local at images/featured-work

    ![idea_03](./img/10.png)

5.  from line 433 to 473 is the  partner part.

    ![idea_04](./img/5.png)

6.  from line 479 to 582 is the people part.

    ![idea_05](./img/6.png)

7.  from line 649 to 680 is the footer part.

    ![idea_05](./img/7.png)

8.  in the redirect.html change url to redirect url.

    ![idea_05](./img/11.png)


