# WebSource
Made by Shuai Zheng Advisor: Prof. Homayoun Yousefi'zadeh

Prerequement:


To simulate the website, below are required:

1. HTML IDE (Sublime, Atom, and so on )
    Can be downloaded from webite:
    https://www.sublimetext.com/


2. Browser (Chrome, firefox, and so on )
    https://www.google.com/chrome/



# Test (Step 1):


With above preparation done, edit the website with following steps:


1.  Open index.html using sublime to edit, Open index.html using chrome or firefox to display the website.


# Deploy Using Cpanel(Step 2):

2.  compress .html, images, js, and css file inside one .zip file


3. buy host server such as (https://www.bluehost.com/) or (https://www.hostgator.com).

4. after buy host server, login in and click cpanel.

5. use file manager to upload file.

    ![idea_05](./img/21.png)

6. click submit

    ![idea_05](./img/22.png)

7. click upload

    ![idea_05](./img/23.png)

8. select zip file

    ![idea_05](./img/24.png)

9. extract zip file

    ![idea_05](./img/25.png)

10. redirect domain to domian/index.html in the cpanel

    ![idea_05](./img/27.png)

11. after click redirect and set redirect page

    ![idea_05](./img/28.png)

12. in the js/custom.js change your email change in order to people contact with you. 

    ![idea_05](./img/201.png)


